### Diretório: 
src/

### Comando:
javac -d out $(find tarefa -name "*.java")
java -cp out AST