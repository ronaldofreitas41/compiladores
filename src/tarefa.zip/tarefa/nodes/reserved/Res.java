package tarefa.nodes.reserved;

import tarefa.nodes.LNode;

public abstract class Res extends LNode {
    public Res(int l, int c){
        super(l,c);
    }
}