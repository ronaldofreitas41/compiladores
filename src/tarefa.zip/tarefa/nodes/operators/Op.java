package tarefa.nodes.operators;

import tarefa.nodes.LNode;

public abstract class Op extends LNode {
    public Op(int l, int c){
        super(l,c);
    }
}