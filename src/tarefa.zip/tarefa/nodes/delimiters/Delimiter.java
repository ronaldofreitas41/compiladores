package tarefa.nodes.delimiters;

import tarefa.nodes.LNode;

public abstract class Delimiter extends LNode {
    public Delimiter(int line, int col) {
        super(line, col);
    }
}