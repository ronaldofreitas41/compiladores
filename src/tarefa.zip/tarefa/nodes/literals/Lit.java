package tarefa.nodes.literals;

import tarefa.nodes.LNode;

public abstract class Lit extends LNode {
    public Lit(int l, int c) {
        super(l, c);
    }
}